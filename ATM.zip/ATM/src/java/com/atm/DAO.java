package com.atm;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DAO {
    
    Connection con;
    public DAO(){
        String url="jdbc:mysql://localhost:3306/atm";
        String username="root";
        String password="";        
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con=(Connection) DriverManager.getConnection(url,username,password);
        } 
        catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(DAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    public boolean check(String atmnum) throws ClassNotFoundException, SQLException{
        String sql="select * from tbldetail where atmnum=?";
        PreparedStatement st=(PreparedStatement) con.prepareStatement(sql);
        st.setString(1, atmnum);
        ResultSet rs= st.executeQuery();
        if(rs.next()){
            return true;
        }

        return false;
    }
    public boolean checkpin(String atmnum, String pin) throws ClassNotFoundException, SQLException{
        String sql="select pin from tbldetail where atmnum=?";
        PreparedStatement st=(PreparedStatement) con.prepareStatement(sql);
        st.setString(1, atmnum);
        ResultSet rs= st.executeQuery();
        rs.next();
        return rs.getString(1).equals(pin);
    }
    
    public boolean updateAmount(String atmnum,int ammount) throws ClassNotFoundException, SQLException{
        String sql="select balance from tbldetail where atmnum=?";
        PreparedStatement st=(PreparedStatement) con.prepareStatement(sql);
        st.setString(1, atmnum);
        ResultSet rs= st.executeQuery();
        rs.next();
        int deduct=Integer.parseInt(rs.getString(1))-ammount;
        String update="update tbldetail SET balance=? WHERE atmnum=?";
        PreparedStatement stt=(PreparedStatement) con.prepareStatement(update);
        
        stt.setString(1, String.valueOf(deduct));
        stt.setString(2, atmnum);
        return stt.execute();
    }
    public boolean Diposit(String atmnum,int ammount) throws ClassNotFoundException, SQLException{
        String sql="select balance from tbldetail where atmnum=?";
        PreparedStatement st=(PreparedStatement) con.prepareStatement(sql);
        st.setString(1, atmnum);
        ResultSet rs= st.executeQuery();
        rs.next();
        int credit=Integer.parseInt(rs.getString(1))+ammount;
        String update="update tbldetail SET balance=? WHERE atmnum=?";
        PreparedStatement stt=(PreparedStatement) con.prepareStatement(update);
        
        stt.setString(1, String.valueOf(credit));
        stt.setString(2, atmnum);
        return stt.execute();
    }
    
    public boolean transfer(String atmnum,String name,String account,String ifsc,int ammount) throws ClassNotFoundException, SQLException{
            
        String sql="select name,ifsc from tbldetail where atmnum=?";
        PreparedStatement st=(PreparedStatement) con.prepareStatement(sql);
        st.setString(1, account);
        ResultSet rs= st.executeQuery();
        rs.next();
        if(rs.getString(1).equals(name) && rs.getString(2).equals(ifsc))
        {
            boolean b= updateAmount(atmnum,ammount);
            boolean b1= Diposit(account,ammount);
            return true; 
        }
        else 
            return false;
    }
    
    public ArrayList accountDetail(String atmnum) throws ClassNotFoundException, SQLException{
            
        String sql="select * from tbldetail where atmnum=?";
        PreparedStatement st=(PreparedStatement) con.prepareStatement(sql);
        st.setString(1, atmnum);
        ResultSet rs= st.executeQuery();
        rs.next();
        ArrayList <String> arr = new ArrayList<>();
        arr.add(0, rs.getString(2));
        arr.add(1, rs.getString(3));
        arr.add(2, rs.getString(4));
        arr.add(3, rs.getString(1));
        arr.add(4, rs.getString(7));
        arr.add(5, rs.getString(5));
        arr.add(6, rs.getString(6));
//        System.out.println(arr);
        return arr;
    }
    
    
    
}
