package com.atm;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.tomcat.jni.Time;

@WebServlet(name = "withdraw", urlPatterns = {"/withdrawAction"})
public class withdraw extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out= response.getWriter();
        HttpSession session=request.getSession();
        String atmnum=(String) session.getAttribute("atmnum");
        String pin= request.getParameter("pin");
        String action= (String) session.getAttribute("action");
        DAO dao=new DAO();
        try {
            if(dao.checkpin(atmnum, pin))
            {
                if("withdraw".equals(action))
                {
                    int money =(int) session.getAttribute("amount");
                    dao.updateAmount(atmnum, money);
                    session.removeAttribute("withdraw");
                    session.removeAttribute("atmnum");
                    session.removeAttribute("amount");
                    session.invalidate();               
                    response.sendRedirect("login.jsp?"+ action +"="+money);
                }
                else if("diposit".equals(action))
                {
                    int money =(int) session.getAttribute("amount");
                    dao.Diposit(atmnum, money);
                    session.removeAttribute("diposit");
                    session.removeAttribute("atmnum");
                    session.removeAttribute("amount");
                    session.invalidate();               
                    response.sendRedirect("login.jsp?"+ action +"="+money);
                }
                else if("tranfer".equals(action))
                {
                    int money =(int) session.getAttribute("amount");
                    String name = (String) session.getAttribute("name");
                    String account = (String) session.getAttribute("accountnum");
                    String ifsc = (String) session.getAttribute("ifsc");
                    if(dao.transfer(atmnum, name, account, ifsc, money))
                    {
                        session.removeAttribute("tranfer");
                        session.removeAttribute("atmnum");
                        session.removeAttribute("amount");
                        session.invalidate();               
                        response.sendRedirect("login.jsp?"+ action +"="+money);
                    }
                    else
                        out.println("Something Went Wrong...................");
                }
                else if("enquiry".equals(action))
                {
                    ArrayList<String> detail = dao.accountDetail(atmnum);
                    session.removeAttribute("enquiry");
                    System.out.println(detail);
                    session.setAttribute("n",detail.get(0));
                    session.setAttribute("add",detail.get(1));
                    session.setAttribute("bank",detail.get(2));
                    session.setAttribute("atm",detail.get(3));
                    session.setAttribute("type",detail.get(4));
                    session.setAttribute("ifsc",detail.get(5));
                    session.setAttribute("bal",detail.get(6));
                    
                    response.sendRedirect("accountdetail.jsp");
                }
                
            }
            else {
                out.println("Wrong Pin"+pin);
            }
        } catch (Exception ex) {
            System.out.println(ex);
        }
        
        
    }
}
